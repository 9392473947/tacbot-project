print("chaithu")
